 

import UIKit

class TabBarHome: UITabBarController {

    override func viewDidLoad() {
        
        print("tabbar")
    }
    
 
}
